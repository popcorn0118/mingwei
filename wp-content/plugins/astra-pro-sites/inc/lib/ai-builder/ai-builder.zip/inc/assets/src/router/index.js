// Export the default export from the file
export { default } from './router';

// Export other exports from the file
export * from './routes';
export { default as steps } from './routes';
export * from './hooks';
